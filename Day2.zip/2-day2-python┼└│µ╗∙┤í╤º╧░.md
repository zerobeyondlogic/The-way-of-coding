# Day2：python爬虫基础学习（大嘘）

[TOC]

## 教材&参考：

1. [千锋Python爬虫教程](https://www.bilibili.com/video/BV1v7411W76c)
2. [廖雪峰的python教程](https://www.liaoxuefeng.com/wiki/1016959663602400)



## 学习过程

**我坦诚，我有罪。**

今天看了几集爬虫教程视频，但没有敲代码。

因为我才刚敲了没几个字，就发现VScode的语法高亮太不爽了，换了几种配色，又装了几个所谓的语法插件，发现还是不够顶。

说实话。确实还是更喜欢Sublime的配色方案，懒得自己调了，虽然感觉靠vscode也可以实现，但谁让我是懒猪呢……电脑上也有**pycharm**，**visuals studio**什么的，但是这些大块头实在不舒服。我这种菜鸡还是更喜欢轻量化的编辑器。最后决定用回Sublime。

但是Sublime毕竟是一个轻量级的类似于文本编辑器的玩意，和VScode功能没法比。

要想愉快地使用它，还得调教一下才行。

所以今天的主题其实是**Sublime配置教程**。

## Sublime配置教程

### 下载&安装

这个真的要教么？算了，我姑且放两个下载链接吧。一个官网，一个云盘，暂时是最新版。要是你是很久以后看到的这篇文章请自己去下载最新版。

**[Sublime官网下载链接](http://www.sublimetext.com/3)（持续更新）（全版本）**

**windowsX64版本（2020/04/24）([曲奇云盘](https://quqi.gblhgk.com/s/1062967/iwhuRYPQV9uLOryR))**

至于购买License($80)，请自行购买，建议**支持正版**。

破解的教程也有，自行搜索。不过其实sublime不买License，不破解，又不是不能用……

顺带一提，Linux版本的Sublime安装还是有很多坑的，比如没有Docker图标什么的，以后有时间也出一个小教程（不过会用Linux的自己也会解决吧……）

### 语言（设置中文）

**英文好的请跳过这步**（另外如果没有科学上网安装这些会很慢，请耐心）

1. 找到**Tools->Command Palette...**”选项
2. 输入**ipc** ,点击 **Install Package Control**，调出 **Package Control**
3. 找到  **Preferences->Package Control**
4. 在弹出的命令行输入框，输入**ip**，点击**install Package**
5. 在弹出的命令行输入框，输入**clz**，点击“**ChineseLocalizations**”
6. 等待安装完成，注意下方，完成时下方状态栏的等号会停止移动
7. 以后想换回英语可以在**帮助->Language** 里面切换

### 设置字体/配色

1. 打开Preferences –>>Settings
2. 在右侧用户配置框里自行更改字体大小，主体，Tab键对应空格数量（建议4个）,这是我的配置

``` python
{
"color_scheme": "Packages/Color Scheme - Default/Monokai.sublime-color-scheme",
"font_face": "Consolas",
"font_size": 15,
"ignored_packages":["Vintage"],
"tab_size": 4,
"translate_tabs_to_spaces": true,
"expand_tabs_on_save": true
}
```

### 配置Python环境

这个我有必要好好说说。

搞过好多种方法。

在此一一列举：

#### 使用python官方编译器(不推荐)

1. 安装python（这个不在本教程范围内，记得装的时候勾选add to path）

2. 配置：在sublime选项卡里打开Tools > Build System > New Build System..

3. 点击New Build System后，在空配置文件里写入下列信息。（**请将路径换成你的python实际安装路径***）,然后按ctrl+s，将文件保存在默认路径，文件名命名为“Python3”(自己随便起，只要分得清)

   ```python
   {
       "cmd":["C:/Users/beyondlogic/AppData/Local/Programs/Python/Python38/python.exe","-u","$file"],
       "file_regex": "^[ ]*File \"(...*?)\", line ([0-9]*)",
       "selector": "source.python",
   }
   ```

4. 打开Tools > Build System，选择新建好的Python3即可

5. 新建test.py文件，输入简单python语句,例如

   ```python
   print(“hello world”)
   ```
   
   按Ctrl+B运行即可
   
   优点：无需额外安装软件，简单易用
   
   缺点：**不支持input**……对turtle这些的支持好像也有点问题

#### 使用Anaconda+SublimeREPL（简单可用）

##### 安装配置anaconda

1. 下载安装：根据自己的系统选择版本，建议选择Python3.x的版本，python2已经是时代的弃子了

   **[官网-全平台持续更新](https://www.anaconda.com/products/individual#Downloads)，**浏览器下不动可以复制下载链接到迅雷等下载工具里下载

   **Python 3.7版本 windowsX64平台（2020/04/24）** （[曲奇云盘](https://quqi.gblhgk.com/s/1062967/iybedw4BRgSbIdiL)）

2. 安装过程一路默认就行了。安装过程中有一步Advanced Options,添加到系统变量一定要勾上！

3. 检查是否添加到路径，可以在“此电脑”上右键，选择

   属性——高级系统设置——环境变量

   在系统变量选项卡中找到“Path”双击查看是否有Python的路径存在

   如果没有，就手动为其添加。

##### 安装配置SublimeREPL

2. 打开 `Preferences --> Package Control `子菜单，输入i,选择`Install Package`

3. 输入SublimeREPL，点击安装

4. 装完之后点击`Preferences --> Key Bindings`

5. 在`User`文件里粘贴以下代码：

   ```python
   [{ "keys": ["f5"],
     "caption": "SublimeREPL: Python - RUN current file",
     "command": "run_existing_window_command", 
     "args":{
         "id": "repl_python_run",
     	  "file": "config/Python/Main.sublime-menu"}
    }]
   ```

5. 以后运行Python代码时直接按`F5`就可以了，也可自行更改为其他顺手的快捷键，注意不要冲突

##### sublime插件安装

打开 `Preferences --> Package Control `子菜单，输入i,选择`Install Package`

1. 为了使得sublime支持python代码自动补全，安装`anaconda`插件
2. `SublimeHighLight`: 在复制代码的同时复制文字样式，复制粘贴代码到word等文字软件后也能保持代码高亮（要选择Copy as RTF）

1. 安装`All Autocomplete `，支持从所有文件中匹配关键字，在多文件项目中有用
2. `SublimeCodeIntel` 代码自动完成引擎，支持多语言
3. `AutoFileName`：自动补全文件路径
4. `BracketHighlighter`：高亮加强，支持不同对的括号不同颜色！
5. `BufferScroll` `：支持同时分屏同一个文件，可以同时书写一个文件的不同部分不必滚来滚去。//我安装时这个好像木得了……
6. `Color Highlighter`：一个色环插件，便于编辑和预览颜色
7. `DocBlockr`：代码补全插件（多语言）
8. `Emmet`：提高HTML/CSS代码编写效率

####  附赠：Sublime快捷键

**Sublime Text 3 快捷键精华版**

**选择类**

**Ctrl+D** 选中光标所占的文本，继续操作则会选中下一个相同的文本。

**Alt+F3** 选中文本按下快捷键，即可一次性选择全部的相同文本进行同时编辑。举个栗子：快速选中并更改所有相同的变量名、函数名等。

**Ctrl+L** 选中整行，继续操作则继续选择下一行，效果和 **Shift+↓** 效果一样。

**Ctrl+Shift+L** 先选中多行，再按下快捷键，会在每行行尾插入光标，即可同时编辑这些行。

**Ctrl+Shift+M** 选择括号内的内容（继续选择父括号）。举个栗子：快速选中删除函数中的代码，重写函数体代码或重写括号内里的内容。

**Ctrl+M** 光标移动至括号内结束或开始的位置。

**Ctrl+Enter** 在下一行插入新行。举个栗子：即使光标不在行尾，也能快速向下插入一行。

**Ctrl+Shift+Enter** 在上一行插入新行。举个栗子：即使光标不在行首，也能快速向上插入一行。

**Ctrl+Shift+[** 选中代码，按下快捷键，折叠代码。

**Ctrl+Shift+]** 选中代码，按下快捷键，展开代码。

**Ctrl+K+0** 展开所有折叠代码。

**Ctrl+←** 向左单位性地移动光标，快速移动光标。

**Ctrl+→** 向右单位性地移动光标，快速移动光标。

**shift+↑** 向上选中多行。

**shift+↓** 向下选中多行。

**Shift+←** 向左选中文本。

**Shift+→** 向右选中文本。

**Ctrl+Shift+←** 向左单位性地选中文本。

**Ctrl+Shift+→** 向右单位性地选中文本。

**Ctrl+Shift+↑** 将光标所在行和上一行代码互换（将光标所在行插入到上一行之前）。

**Ctrl+Shift+↓** 将光标所在行和下一行代码互换（将光标所在行插入到下一行之后）。

**Ctrl+Alt+↑** 向上添加多行光标，可同时编辑多行。

**Ctrl+Alt+↓** 向下添加多行光标，可同时编辑多行。

**编辑类**

**Ctrl+J** 合并选中的多行代码为一行。举个栗子：将多行格式的CSS属性合并为一行。

**Ctrl+Shift+D** 复制光标所在整行，插入到下一行。

**Tab** 向右缩进。

**Shift+Tab** 向左缩进。

**Ctrl+K+K** 从光标处开始删除代码至行尾。

**Ctrl+Shift+K** 删除整行。

**Ctrl+/** 注释单行。

**Ctrl+Shift+/** 注释多行。

**Ctrl+K+U** 转换大写。

**Ctrl+K+L** 转换小写。

**Ctrl+Z** 撤销。

**Ctrl+Y** 恢复撤销。

**Ctrl+U** 软撤销，感觉和 **Gtrl+Z** 一样。

**Ctrl+F2** 设置书签

**Ctrl+T** 左右字母互换。

**F6** 单词检测拼写

**搜索类**

**Ctrl+F** 打开底部搜索框，查找关键字。

**Ctrl+shift+F** 在文件夹内查找，与普通编辑器不同的地方是sublime允许添加多个文件夹进行查找，略高端，未研究。

**Ctrl+P** 打开搜索框。举个栗子：1、输入当前项目中的文件名，快速搜索文件，2、输入@和关键字，查找文件中函数名，3、输入：和数字，跳转到文件中该行代码，4、输入#和关键字，查找变量名。

**Ctrl+G** 打开搜索框，自动带：，输入数字跳转到该行代码。举个栗子：在页面代码比较长的文件中快速定位。

**Ctrl+R** 打开搜索框，自动带@，输入关键字，查找文件中的函数名。举个栗子：在函数较多的页面快速查找某个函数。

**Ctrl+：** 打开搜索框，自动带#，输入关键字，查找文件中的变量名、属性名等。

**Ctrl+Shift+P** 打开命令框。场景栗子：打开命名框，输入关键字，调用sublime text或插件的功能，例如使用package安装插件。

**Esc** 退出光标多行选择，退出搜索框，命令框等。

**显示类**

**Ctrl+Tab** 按文件浏览过的顺序，切换当前窗口的标签页。

**Ctrl+PageDown** 向左切换当前窗口的标签页。

**Ctrl+PageUp** 向右切换当前窗口的标签页。

**Alt+Shift+1** 窗口分屏，恢复默认1屏（非小键盘的数字）

**Alt+Shift+2** 左右分屏-2列

**Alt+Shift+3** 左右分屏-3列

**Alt+Shift+4** 左右分屏-4列

**Alt+Shift+5** 等分4屏

**Alt+Shift+8** 垂直分屏-2屏

**Alt+Shift+9** 垂直分屏-3屏

**Ctrl+K+B** 开启/关闭侧边栏。

**F11** 全屏模式

**Shift+F11** 免打扰模式

## 今日总结

​	代码量：**0行**

​	学习了：

​	Sublime配置并撰写了教程

​	最后，欢迎加群玩耍~QQ群：218531911

  





